require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const http = require('http');
const { Server } = require('socket.io');
const axios = require('axios');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const FB_VERIFY_TOKEN = process.env.FB_VERIFY_TOKEN;
const FACEBOOK_PAGE_ACCESS_TOKEN = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;
const ZALO_OA_ACCESS_TOKEN = process.env.ZALO_OA_ACCESS_TOKEN;
const PORT = process.env.PORT || 3001;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function initDb() {
  const sql = fs.readFileSync(path.join(__dirname, 'db.sql')).toString();
  await pool.query(`CREATE EXTENSION IF NOT EXISTS "pgcrypto";`);
  await pool.query(sql);
}
initDb().catch(err => {
  console.error('DB init error', err);
  process.exit(1);
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
io.on('connection', socket => {
  console.log('socket connected', socket.id);
  socket.on('join', () => {
    socket.join('agents');
  });
});

async function findOrCreateConversation(provider, provider_thread_id, customer_id, customer_name) {
  const res = await pool.query(
    `SELECT * FROM conversations WHERE provider=$1 AND provider_thread_id=$2 LIMIT 1`,
    [provider, provider_thread_id]
  );
  if (res.rows.length) return res.rows[0];
  const insert = await pool.query(
    `INSERT INTO conversations(provider, provider_thread_id, customer_id, customer_name) VALUES($1,$2,$3,$4) RETURNING *`,
    [provider, provider_thread_id, customer_id, customer_name]
  );
  return insert.rows[0];
}

async function saveMessage({ conversation_id, provider, external_id, sender_type, sender_id, body, attachments, direction }) {
  const r = await pool.query(
    `INSERT INTO messages(conversation_id, provider, external_id, sender_type, sender_id, body, attachments, direction) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [conversation_id, provider, external_id, sender_type, sender_id, body, attachments ? JSON.stringify(attachments) : null, direction]
  );
  await pool.query(`UPDATE conversations SET updated_at = now() WHERE id = $1`, [conversation_id]);
  return r.rows[0];
}

// --- CONNECTED PAGES CRUD ---
app.get('/api/pages', async (req, res) => {
  const r = await pool.query(`SELECT id, provider, provider_page_id, name, created_at FROM connected_pages ORDER BY created_at DESC`);
  res.json(r.rows);
});

app.post('/api/pages', async (req, res) => {
  const { provider, provider_page_id, name, access_token } = req.body;
  const r = await pool.query(`INSERT INTO connected_pages(provider, provider_page_id, name, access_token) VALUES($1,$2,$3,$4) RETURNING *`, [provider, provider_page_id, name, access_token]);
  res.json(r.rows[0]);
});

// --- FACEBOOK OAUTH ---
app.get('/auth/facebook', (req, res) => {
  const redirect_uri = `${process.env.BASE_URL}/auth/facebook/callback`;
  const fbOauth = `https://www.facebook.com/v17.0/dialog/oauth?client_id=${process.env.FB_APP_ID}&redirect_uri=${encodeURIComponent(redirect_uri)}&scope=pages_show_list,pages_manage_metadata,pages_messaging`;
  res.redirect(fbOauth);
});

app.get('/auth/facebook/callback', async (req, res) => {
  const code = req.query.code;
  const redirect_uri = `${process.env.BASE_URL}/auth/facebook/callback`;
  try {
    const tokenRes = await axios.get('https://graph.facebook.com/v17.0/oauth/access_token', {
      params: {
        client_id: process.env.FB_APP_ID,
        client_secret: process.env.FB_APP_SECRET,
        redirect_uri,
        code
      }
    });
    const userAccessToken = tokenRes.data.access_token;
    const pagesRes = await axios.get('https://graph.facebook.com/v17.0/me/accounts', {
      params: { access_token: userAccessToken }
    });
    const pages = pagesRes.data.data;
    // save pages to connected_pages
    for (const p of pages) {
      await pool.query(`INSERT INTO connected_pages(provider, provider_page_id, name, access_token) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`, ['facebook', p.id, p.name, p.access_token]);
    }
    res.send(`<h3>Linked ${pages.length} page(s)</h3><pre>${JSON.stringify(pages,null,2)}</pre>`);
  } catch (err) {
    console.error('Facebook auth error:', err.response?.data || err.message);
    res.status(500).send('Error linking Facebook.');
  }
});

// --- FACEBOOK WEBHOOK ---
app.get('/webhook/facebook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token === FB_VERIFY_TOKEN) {
    console.log('FB webhook verified');
    return res.status(200).send(challenge);
  }
  res.sendStatus(403);
});

app.post('/webhook/facebook', async (req, res) => {
  const body = req.body;
  if (body.object === 'page') {
    for (const entry of body.entry || []) {
      for (const ev of entry.messaging || []) {
        if (ev.message && !ev.message.is_echo) {
          const senderId = ev.sender.id;
          const text = ev.message.text || '';
          const provider_thread_id = senderId;
          const conv = await findOrCreateConversation('facebook', provider_thread_id, senderId, null);
          const msg = await saveMessage({
            conversation_id: conv.id,
            provider: 'facebook',
            external_id: ev.message.mid || null,
            sender_type: 'customer',
            sender_id: senderId,
            body: text,
            attachments: ev.message.attachments || null,
            direction: 'inbound'
          });
          io.to('agents').emit('message:new', { conversation: conv, message: msg });
        }
      }
    }
    return res.status(200).send('EVENT_RECEIVED');
  }
  res.sendStatus(404);
});

// --- ZALO WEBHOOK ---
app.post('/webhook/zalo', async (req, res) => {
  try {
    const body = req.body;
    // simple handling: user_send_text event
    if (body.event_name && body.sender) {
      const senderId = body.sender.user_id;
      const text = body.message && body.message.text ? body.message.text : '';
      const provider_thread_id = senderId;
      const conv = await findOrCreateConversation('zalo', provider_thread_id, senderId, body.sender.display_name || null);
      const msg = await saveMessage({
        conversation_id: conv.id,
        provider: 'zalo',
        external_id: body.message && body.message.message_id ? body.message.message_id : null,
        sender_type: 'customer',
        sender_id: senderId,
        body: text,
        attachments: null,
        direction: 'inbound'
      });
      io.to('agents').emit('message:new', { conversation: conv, message: msg });
    }
    res.status(200).send('OK');
  } catch (err) {
    console.error('zalo webhook error', err);
    res.status(500).send('ERR');
  }
});

// Public API: list conversations
app.get('/api/conversations', async (req, res) => {
  const r = await pool.query(`SELECT * FROM conversations ORDER BY updated_at DESC LIMIT 200`);
  res.json(r.rows);
});

// Conversation detail & messages
app.get('/api/conversations/:id', async (req, res) => {
  const id = req.params.id;
  const c = await pool.query(`SELECT * FROM conversations WHERE id=$1`, [id]);
  if (!c.rows.length) return res.status(404).send('Not found');
  const m = await pool.query(`SELECT * FROM messages WHERE conversation_id=$1 ORDER BY created_at ASC`, [id]);
  res.json({ conversation: c.rows[0], messages: m.rows });
});

// Send message as agent (outbound)
app.post('/api/conversations/:id/messages', async (req, res) => {
  const id = req.params.id;
  const { text } = req.body;
  const convRes = await pool.query(`SELECT * FROM conversations WHERE id=$1`, [id]);
  if (!convRes.rows.length) return res.status(404).send('Conv not found');
  const conv = convRes.rows[0];

  // Save message locally
  const msg = await saveMessage({
    conversation_id: conv.id,
    provider: conv.provider,
    external_id: null,
    sender_type: 'agent',
    sender_id: 'agent_demo',
    body: text,
    attachments: null,
    direction: 'outbound'
  });
  io.to('agents').emit('message:new', { conversation: conv, message: msg });

  // Now actually call provider API to send message
  try {
    if (conv.provider === 'facebook') {
      await axios.post(`https://graph.facebook.com/v17.0/me/messages?access_token=${FACEBOOK_PAGE_ACCESS_TOKEN}`, {
        messaging_type: 'RESPONSE',
        recipient: { id: conv.provider_thread_id },
        message: { text }
      });
    } else if (conv.provider === 'zalo') {
      // Zalo send example (requires OA access token)
      await axios.post(`https://openapi.zalo.me/v2.0/oa/message?access_token=${ZALO_OA_ACCESS_TOKEN}`, {
        recipient: { user_id: conv.provider_thread_id },
        message: { text }
      });
    }
  } catch (err) {
    console.error('send error', err.response ? err.response.data : err.message);
  }

  res.json(msg);
});

// Basic pages list endpoint for frontend
app.get('/api/pages', async (req, res) => {
  const r = await pool.query(`SELECT id, provider, provider_page_id, name FROM connected_pages ORDER BY created_at DESC`);
  res.json(r.rows);
});

server.listen(PORT, () => {
  console.log(`Backend listening on ${PORT}`);
});
