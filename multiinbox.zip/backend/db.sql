CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE TABLE IF NOT EXISTS connected_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider varchar(50) NOT NULL, -- facebook | zalo
  provider_page_id varchar(255) NOT NULL,
  name varchar(255),
  access_token text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider varchar(50) NOT NULL,
  provider_thread_id varchar(255) NOT NULL,
  customer_id varchar(255),
  customer_name varchar(255),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid REFERENCES conversations(id) ON DELETE CASCADE,
  provider varchar(50) NOT NULL,
  external_id varchar(255),
  sender_type varchar(20) NOT NULL,
  sender_id varchar(255),
  body text,
  attachments jsonb,
  direction varchar(10) NOT NULL,
  created_at timestamptz DEFAULT now()
);
